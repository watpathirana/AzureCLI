# Azure & Microsoft Graph Sessions — User & Admin Guide

This document explains how sessions work for `init.ps1` (Azure CLI) and `send.ps1` (Microsoft Graph), how to view or remove them locally, and what tenant administrators can see in the Microsoft web portals.

---

## Overview: Two Separate Sessions

| Script | Auth type | Used for | Session stored |
|--------|-----------|----------|----------------|
| `init.ps1` | Azure CLI (`az login`) | VMs, storage, resource groups, networking | Azure CLI token cache (on disk) |
| `send.ps1` | Microsoft Graph (device code) | Mail, profile, calendar, files, Teams | `D:\ps\.graph-session.json` |

These are **independent**. Signing into one does **not** sign you into the other.

---

## Part 1 — Local Sessions (Your Machine)

### View Azure CLI session (`init.ps1`)

```powershell
az account show
az account show -o table
az account list -o table
```

Shows: signed-in user, subscription, tenant.

### View Graph session (`send.ps1`)

The token is stored in:

```
D:\ps\.graph-session.json
```

Fields include:
- `account` — signed-in email
- `access_token` — short-lived JWT (do not share)
- `refresh_token` — used to get new access tokens
- `scopes` — permissions granted (e.g. `User.Read`, `Mail.Send`, `Files.Read`)
- `expires_at` — when the access token expires

When `send.ps1` runs, the menu also shows user, scopes, and expiry at the top.

### Remove Azure CLI session

```powershell
az logout
```

Next run of `init.ps1` will prompt for login again.

### Remove Graph session

```powershell
Remove-Item "D:\ps\.graph-session.json" -Force
```

Or from `D:\ps`:

```powershell
del .graph-session.json
```

Next run of `send.ps1` will prompt for device-code sign-in again.

### Full local reset (both scripts)

```powershell
cd D:\ps
az logout
Remove-Item ".graph-session.json" -Force -ErrorAction SilentlyContinue
```

### Security note

- Never commit `.graph-session.json` to git (it is listed in `.gitignore`).
- Never share access tokens or refresh tokens.
- Delete the file when finished on a shared computer.

---

## Part 2 — View Sessions on the Web (Any User)

### Your sign-in history

**URL:** [https://mysignins.microsoft.com](https://mysignins.microsoft.com)

Shows:
- Recent sign-ins
- App used (e.g. Azure CLI, Microsoft Graph Command Line Tools)
- Location and IP
- Success or failure

### Azure portal session

**URL:** [https://portal.azure.com](https://portal.azure.com)

- Click your profile (top right) to see signed-in account and tenant.
- **Sign out** ends the browser portal session only.

### Apps with access to your Microsoft 365 data

**URL:** [https://myaccount.microsoft.com](https://myaccount.microsoft.com)

- **Settings** → **Privacy** → **Apps and services**
- Review and revoke apps that can read mail, files, etc.

---

## Part 3 — Tenant Admin: What You Can and Cannot See

### Cannot view (by design)

| Item | Admin can view? |
|------|-----------------|
| User `access_token` (JWT string) | **No** |
| User `refresh_token` | **No** |
| `.graph-session.json` on a user's PC | **No** |

Microsoft does not expose raw tokens in the portal, logs, or Graph API. Anyone with a valid token can act as that user until it expires or is revoked.

### Can view and audit

| What | Where |
|------|--------|
| Who signed in, when, from where | Entra **Sign-in logs** |
| Which app was used | Entra **Sign-in logs** |
| Who consented to an app | Entra **Audit logs** |
| Which users have access to an app | **Enterprise applications** |
| User activity (mail, files) | Microsoft 365 **Audit** (Purview) |

---

## Part 4 — Tenant Admin: Step-by-Step

### Sign-in logs (who used Azure CLI or Graph)

1. Open [https://entra.microsoft.com](https://entra.microsoft.com)
2. **Identity** → **Monitoring & health** → **Sign-in logs**
3. Filter by:
   - **User** — specific person
   - **Application** — e.g. *Azure CLI*, *Microsoft Graph Command Line Tools*
   - **Date** and **Status**

You see user, app, IP, location, MFA result — **not** the token.

### Enterprise applications (which apps have access)

1. **Entra** → **Applications** → **Enterprise applications**
2. Search for the app (e.g. **Microsoft Graph Command Line Tools**)
3. Open:
   - **Users and groups** — who has access
   - **Permissions** — delegated scopes / admin consent

### Audit logs (consent and permission changes)

1. **Entra** → **Monitoring** → **Audit logs**
2. Filter for activities such as:
   - *Consent to application*
   - *Add delegated permission grant*
   - *Add app role assignment*

### Revoke user access (without seeing tokens)

| Action | Steps |
|--------|--------|
| Revoke all sessions for one user | **Entra** → **Users** → select user → **Revoke sessions** |
| Remove user from an app | **Enterprise applications** → app → **Users and groups** → remove |
| Disable app for the org | **Enterprise applications** → app → **Properties** → **Enabled for users to sign-in?** = No |

After revoke, tokens stop working quickly; the user must sign in again.

### Microsoft 365 audit (what a user did)

**Microsoft Purview** / **Compliance** → **Audit**

Useful for mail sent, file access, and other M365 activity. This is **activity**, not token content.

---

## Part 5 — Mapping Scripts to Portal Activity

| Your script | Sign-in log application | Local session |
|-------------|-------------------------|---------------|
| `init.ps1` | **Azure CLI** | `az login` cache |
| `send.ps1` | **Microsoft Graph Command Line Tools** (client ID `14d82eec-204b-4c2f-b7e8-296a70dab67e`) | `.graph-session.json` |

### Example admin check: “Did someone use Graph to send mail?”

1. **Sign-in logs** — filter by user and *Microsoft Graph Command Line Tools*
2. **Enterprise applications** — open that app → **Users and groups**
3. **Audit logs** — filter consent events for that app
4. If needed: **Revoke sessions** for that user
5. Optionally: **M365 Audit** — search for `Send` mail events

---

## Part 6 — Microsoft Graph Permissions (send.ps1)

`send.ps1` may request different scopes per menu category:

| Scope set | Permissions | Used for |
|-----------|-------------|----------|
| base | `User.Read`, `Mail.Send` | Profile, send email |
| mail | + `Mail.Read` | Inbox, folders |
| calendar | + `Calendars.Read` | Calendar events |
| files | + `Files.Read` | OneDrive |
| contacts | + `Contacts.Read` | Contacts |
| teams | + `Team.ReadBasic.All`, `Chat.Read` | Teams, chats |
| todo | + `Tasks.Read` | To Do lists |

First use of a category may trigger an extra device-code sign-in to grant new scopes.

Some org-wide commands require **admin consent**; users will see access denied until an admin approves the app in Entra.

---

## Part 7 — Quick Reference Links

| Purpose | URL |
|---------|-----|
| Your sign-in history | [mysignins.microsoft.com](https://mysignins.microsoft.com) |
| Azure portal | [portal.azure.com](https://portal.azure.com) |
| Entra admin center | [entra.microsoft.com](https://entra.microsoft.com) |
| Account & app permissions | [myaccount.microsoft.com](https://myaccount.microsoft.com) |
| Graph API reference | [Microsoft Graph REST API](https://learn.microsoft.com/en-us/graph/api/overview) |
| Graph permissions | [Permissions reference](https://learn.microsoft.com/en-us/graph/permissions-reference) |

---

## Part 8 — Common Commands Cheat Sheet

### Azure (`init.ps1`)

```powershell
.\init.ps1
az account show
az account list -o table
az group list -o table
az vm list -o table
az logout
```

### Graph (`send.ps1`)

```powershell
.\send.ps1
Remove-Item "D:\ps\.graph-session.json" -Force   # sign out Graph locally
```

### Admin (PowerShell with appropriate roles)

```powershell
# Connect as admin (separate from init.ps1 / send.ps1)
Connect-MgGraph -Scopes "AuditLog.Read.All","Directory.Read.All"

# Recent sign-ins (admin)
Get-MgAuditLogSignIn -Top 10 -Filter "userPrincipalName eq 'user@domain.com'"
```

---

## Summary

| Question | Answer |
|----------|--------|
| Can a tenant admin view user access tokens? | **No** |
| Can admin see who signed in and which app? | **Yes** — Sign-in logs |
| Can admin revoke access? | **Yes** — Revoke sessions, remove app assignment |
| Where is `send.ps1` session stored locally? | `D:\ps\.graph-session.json` |
| Where is `init.ps1` session stored? | Azure CLI token cache + `az logout` |
| How to audit Graph script usage? | Sign-in logs + Enterprise apps + Audit logs |

---

*Document for D:\ps — `init.ps1` (Azure CLI) and `send.ps1` (Microsoft Graph). Last updated: June 2026.*
